-- ReaScript Pro: read-only candidate-symbol probe.
-- Run manually inside REAPER; does not edit project state or install extensions.
-- Symbol presence is not full extension/version compatibility.
if type(reaper) ~= "table" then
  error("Run this Lua script inside REAPER.")
end
local lines = {"ReaScript Pro environment probe"}
local function append(key, value)
  lines[#lines + 1] = key .. ": " .. tostring(value)
end
for _, symbol in ipairs({"GetAppVersion", "GetOS"}) do
  if type(reaper[symbol]) == "function" then
    local ok, value = pcall(reaper[symbol])
    append(symbol, ok and value or "probe failed")
  else
    append(symbol, "unavailable")
  end
end
local candidates = {"APIExists", "ValidatePtr2", "MIDI_GetAllEvts",
  "ImGui_CreateContext", "CF_GetSWSVersion", "ReaPack_GetOwner"}
for _, symbol in ipairs(candidates) do
  local present = type(reaper[symbol]) == "function"
  if type(reaper.APIExists) == "function" then
    local ok, result = pcall(reaper.APIExists, symbol)
    if ok then present = result end
  end
  append(symbol, present and "symbol present" or "symbol absent")
end
local report = table.concat(lines, "\n") .. "\n"
if type(reaper.ShowConsoleMsg) == "function" then
  reaper.ShowConsoleMsg(report)
else
  print(report)
end
