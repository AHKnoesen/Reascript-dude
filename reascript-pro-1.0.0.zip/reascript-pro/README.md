# ReaScript Pro

Private skills-only REAPER Lua development assistant, version 1.0.0. Eight skills cover API-grounded development, debugging, action scripts, state management, ReaImGui, MIDI, extensions, and clip-launcher prototyping.

No MCP server, local executor, network endpoint, credentials, or direct REAPER control is included. Installation of this plugin does not install REAPER, SWS, ReaPack, or ReaImGui. Lua files are user-run examples; none runs on plugin installation.

Start with the development skill. It routes work and applies the common review contract. Save supplied scripts as UTF-8 .lua files and load through REAPER's Actions list in the appropriate section. Test edits in a disposable project copy.

The optional examples/environment-probe.lua prints version and representative symbol availability. Presence of one symbol does not certify an entire extension or API version. Review its contents, run in REAPER, and paste the report for version-specific work. Package checks do not establish REAPER execution, timing, sound quality, or UI behavior.

See references/contract.md, references/sources.md and references/verification.md. Original package content; third-party manuals are linked, not bundled.
