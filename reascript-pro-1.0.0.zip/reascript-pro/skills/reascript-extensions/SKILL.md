---
name: reascript-extensions
description: Use when detecting or handling SWS, ReaPack, ReaImGui or optional third-party REAPER APIs and named actions.
---

# Extension feature detection

Read ../../references/contract.md and ../../references/sources.md. List required versus optional symbols for the requested feature. Verify each exact function through installed help/upstream documentation, then check reaper.APIExists or documented callable availability in the target runtime before calling.

Version numbers inform compatibility but do not replace capability checks. A representative symbol only proves that symbol exists. ReaPack is a package manager, not evidence that SWS, ReaImGui or any package is installed. Named actions require documented lookup and nonzero resolution in the intended section.

Provide native alternatives where behavior remains correct. If an essential capability is missing, stop before project edits and name the required extension and affected feature. Explain official installation/restart steps when requested; do not silently install, upgrade or change repositories. Do not invent repository URLs or pin a minimum version without evidence.

For optional signatures that changed, use documented version adapters and isolate compatibility logic. Re-check optional UI functionality before enabling its controls. Report present, absent, incompatible and unknown separately.

The user-run ../../examples/environment-probe.lua reports a small set of candidate symbols without editing the project; it is not a complete dependency validator. Replace/extend the probe list with the actual verified symbols needed by the feature. Test missing/partial/available cases and preserve fallback behavior. No local extension detection has occurred merely because the plugin is installed.
