---
name: reascript-state
description: Use when persisting settings, project mappings or deferred-script state, or managing REAPER object lifetimes and cleanup.
---

# State and lifecycle

Read ../../references/contract.md. Separate transient Lua state, global ExtState preferences and project-specific ProjExtState data. Verify persistence flags and storage semantics in target help. Use a plugin-specific namespace and explicit schema version; default cleanly when keys are missing.

Store stable GUIDs and validated scalar values, not serialized userdata/pointers or raw track indices. Resolve identities against the correct project on use and validate pointers with the applicable target API. Handle deletion, undo, project closure and tab switching. Project handle 0 denotes current project in applicable APIs; it is not a permanent project identity.

Treat stored content as untrusted: bound lengths, validate types/ranges, use a documented safe serialization format and never load strings as executable Lua. Validate old schema before migration, preserve recoverable data and report corrupt state without overwriting it silently. Save only on meaningful changes; avoid repeated project dirtying per frame.

Model deferred lifecycle explicitly: initialize -> active -> stopping -> closed or error. Protect each callback and make cleanup idempotent. Own and release only resources created by the script; restore temporary selection, cursor, toggle and refresh state when promised. Do not overwrite intervening user changes with stale snapshots. Reacquire project pointers after context changes.

Test reload, corrupt state, project switching/deletion, normal close, error close and restart. Use ../../references/verification.md; distinguish persisted settings from runtime state and installed plugin state.
