---
name: reascript-midi
description: Use when generating, editing, quantizing or debugging REAPER MIDI notes, CC, text or SysEx, including raw-event workflows.
---

# MIDI editing

Read ../../references/contract.md. Determine target takes, selected-events policy, pooled-source behavior and musical intent. Confirm valid MIDI takes rather than assuming active takes are MIDI. Explain effects on pooled/shared source data and avoid duplicate edits to the same source.

Keep project seconds, QN, take PPQ and MIDI channel numbering distinct; use documented conversion APIs rather than assuming a fixed PPQ resolution or tempo. Check note pitch, velocity and channel ranges, note-off ordering, durations, selection/mute flags and event indices. Define quantization tie-breaks and overlap handling before editing.

Prefer high-level event APIs for ordinary transformations. Precompute changes, handle deletions without index drift, batch edits and restore sorting after a no-sort phase even on errors. Verify API return values. Preserve unrelated CC, text, SysEx, notation, articulation and shape data.

Use MIDI_GetAllEvts / MIDI_SetAllEvts only for a justified throughput or fidelity need. Verify the installed buffer format, signed delta offsets, flags and variable message lengths. Retain empty spacer and metadata events, account for cumulative PPQ, validate boundaries and preserve same-position event ordering where meaningful. Capture original data for a documented recovery strategy; do not silently write a partially parsed buffer.

Test zero events, mixed takes, overlapping notes, tempo changes and source sharing. Compare intended changes and preserved events; verify Undo and note-off behavior. Runtime playback and listening are separate from buffer inspection. See ../../references/verification.md.
