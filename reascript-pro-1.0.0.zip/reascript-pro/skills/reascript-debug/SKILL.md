---
name: reascript-debug
description: Use when a REAPER Lua script errors, behaves incorrectly, leaks resources, or needs a targeted regression fix.
---

# Debugging

Read ../../references/contract.md. Obtain the exact traceback with line numbers, script revision, minimal reproducer, expected/actual behavior, REAPER version and relevant extension versions. If not available, inspect supplied code and proceed with clearly labeled hypotheses.

Locate the first failing operation and trace its inputs. Check nil pointers, stale references, invalid project scope, 0 truthiness, off-by-one indexes, wrong return ordering, API availability and signature drift before rewriting architecture. Distinguish syntax, runtime, API contract, project state, scheduling and performance faults.

Reduce to a disposable-project reproducer; add bounded diagnostics that identify action context and target GUIDs without dumping entire private projects. Capture tracebacks through xpcall with debug.traceback where appropriate. A deferred callback needs its own protected execution and cleanup; protecting only initial scheduling is insufficient.

Patch the smallest cause while preserving intended behavior. Explain root cause and why the change addresses it. Review cleanup on early return and error; log cleanup failures instead of hiding them. Do not use pcall to swallow persistent errors and continue mutating state.

Validate the original failure and one relevant neighboring case. State whether the result is inspected, mocked, user-tested or observed in REAPER; unresolved reproduction remains unresolved. Use ../../references/verification.md for final reporting.
