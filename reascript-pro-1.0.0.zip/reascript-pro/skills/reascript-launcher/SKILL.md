---
name: reascript-launcher
description: Use when designing or prototyping clip-launcher, scene-launch, quantized trigger or live arrangement workflows in REAPER.
---

# Clip-launcher prototypes

Read ../../references/contract.md. Define the clip representation (existing items, regions, takes or another verified engine), audio/MIDI coverage, lane exclusivity, scene meaning, stop behavior, loops and recording scope. Label any unsupported Ableton-style parity explicitly. Start with a non-destructive UI/state prototype when the playback mechanism is unverified.

Model each slot as empty, stopped, queued, playing or error. Model pending stop separately where needed. Define transitions and invariants: one owner per exclusive lane, unique pending request per slot, deterministic scene commit and idempotent cancellation. Distinguish requested, scheduled and observed playing state; do not paint a queued request as confirmed playback.

Separate UI, project mapping, pure musical scheduling and playback adapter. Keep GUID-based mappings and revalidate before dispatch. Preflight a whole scene; specify atomic or partial-failure behavior before launching. Do not substitute an undocumented mute/solo trick and claim full independent clip playback.

Define quantization in musical time with explicit QN versus measure/meter handling. Handle tempo changes, exact-boundary requests, seeks, loop wraps, transport start/stop, late frames and multiple requests before a boundary. Specify whether target time is fixed or recomputed, and discard or reschedule stale requests deterministically.

Lua defer is cooperative UI scheduling, not an audio callback or sample-accurate clock. Report expected timing uncertainty and measure target versus actual dispatch; do not promise gapless or sample-accurate launch from UI polling. Stricter audio/MIDI scheduling may require a verified native engine, JSFX or compiled extension with appropriate constraints. No such engine ships here.

Manage note-offs/all-notes-off only for MIDI channels/resources the prototype owns; avoid silencing unrelated user playback. Test duplicate clicks, scene conflicts, tempo/meter changes, seek, loop wrap, missing targets, stop and close. Deliver a staged prototype, limitations, runnable pieces only for verified adapters and a measurement plan from ../../references/verification.md.
