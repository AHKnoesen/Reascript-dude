---
name: reascript-develop
description: Use when creating, reviewing or planning REAPER Lua ReaScripts, or selecting the appropriate ReaScript Pro workflow.
---

# API-grounded development

Read ../../references/contract.md and ../../references/sources.md before implementation. Route specific work to sibling skills: reascript-debug, reascript-actions, reascript-state, reascript-ui, reascript-midi, reascript-extensions and reascript-launcher. Apply all relevant workflows for mixed tasks.

Convert the request into a short behavior contract: trigger, target selection, project scope, edit, preserved state and success condition. Determine whether a one-shot action, deferred UI tool, MIDI transform or launcher prototype fits. Begin with native Lua; introduce extensions only for a concrete need.

Build an API ledger before coding. Verify exact Lua return ordering and number/string/boolean distinctions, zero-based indices, seconds versus beats/QN/PPQ, object lifetimes and action context. Distinguish ReaScript from JSFX audio processing and C++ extensions. Do not assume a Lua UI script runs in the audio thread.

Separate pure calculations from project access and mutation. Preflight inputs and dependencies, construct a plan, then perform bounded edits. Supply complete code without unexplained placeholders when evidence supports it; identify unresolved API calls explicitly otherwise.

Review the final script against the shared contract, fix found defects and recheck. Use ../../references/verification.md to choose meaningful checks. Deliver the script, concise dependency/API notes, Actions installation steps, usage and an honest validation status. Do not burden simple scripts with unnecessary frameworks.
