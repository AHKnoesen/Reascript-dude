---
name: reascript-ui
description: Use when creating or debugging ReaImGui windows, deferred UI loops, input handling or REAPER tool interfaces.
---

# ReaImGui UI

Read ../../references/contract.md and ../../references/sources.md. Establish installed ReaImGui version and supported API revision. Use its actual API browser/demo and version-matched examples. Verify module-loader syntax and context lifetime rules; do not mix raw reaper.ImGui_* calls and a compatibility module from different revisions.

Check required symbols before UI creation. Missing ReaImGui should produce an actionable dependency message or a useful native fallback, never a cascade of nil calls. No automatic package installation is implied.

Separate model, UI rendering and project commands. Use stable widget IDs, explicit input validation, clear empty/disabled/error states and responsive sizing. Let a button enqueue a command; render loops must not repeat project mutations merely because a window is drawn.

Pair Begin/End and Push/Pop according to the exact installed API contract, including collapsed or hidden window paths. Never invent generic pairing rules across APIs. Schedule one bounded frame per defer call; avoid busy waits, blocking I/O, repeated full-project scans and holding Undo/UI suppression across frames.

Protect each deferred callback, stop rescheduling on closure/error, and perform version-appropriate context/resource cleanup exactly once. Respect keyboard focus and user transport control. Verify open, collapse, resize, close, reopen, missing dependency and project switch. A screenshot proves appearance only; interactive and runtime checks require evidence.
