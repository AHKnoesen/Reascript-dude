---
name: reascript-actions
description: Use when building one-shot REAPER actions, selection edits, toolbar toggles or scripts that invoke Actions commands.
---

# Action scripts

Read ../../references/contract.md. Specify Actions section (main, MIDI editor or other verified context), selection semantics, project and mutation scope. Resolve named command strings using documented lookup and reject unresolved commands. Verify any numeric command ID and section; never guess IDs from action names.

Preflight before opening Undo or suppressing UI refresh. Gather stable target identities before deletions or index-changing operations; delete backwards where needed. Avoid accidental dependence on changing selection during iteration. Respect locked or unsupported targets according to documented behavior.

Group edits with project-scoped Undo_BeginBlock2 / Undo_EndBlock2 after verifying signatures. Balance every PreventUIRefresh increment with a decrement on success, failure and early exit. Keep UI suppression short and synchronous; do not span defer frames. Use protected execution and a single cleanup path. Refresh only what changed. Describe partial mutation honestly: grouping Undo does not roll back a failed action.

No-op cases should avoid gratuitous Undo entries or toolbar changes. For deferred toggles, obtain actual section/command identity from action context, set state with verified APIs and restore it via idempotent atexit cleanup. Do not rely on a hardcoded script command ID.

Deliver save/load/run instructions, expected selection effects and Undo behavior. Verify empty selection, multiple targets and error after a partial edit using ../../references/verification.md.
