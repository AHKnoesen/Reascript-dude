# Authoritative sources and version policy

Checked links on 2026-10-30; refresh for each implementation instead of treating this as a frozen API database.

- Native REAPER Lua API: https://www.reaper.fm/sdk/reascript/reascripthelp.html . Prefer the target installation's generated ReaScript help. The web page explicitly warns it may not be latest.
- ReaScript introduction: https://www.reaper.fm/sdk/reascript/reascript.php . Use it for language/runtime context, not extension signatures.
- ReaImGui upstream: https://codeberg.org/cfillion/reaimgui . The former upstream README at https://github.com/cfillion/reaimgui explicitly directs users here. Prefer the installed ReaImGui API browser, demo and version-compatible examples. Verify compatibility-loader syntax and API revision before generating UI calls.
- SWS: https://sws-extension.org/ and documentation shipped/generated for the installed extension. The website warns that documentation may lag; probe each required symbol.
- ReaPack: https://reapack.com/ and https://github.com/cfillion/reapack . Direct website access returned 403 during authoring; do not infer API semantics from an inaccessible page. Use installed API documentation or authoritative source when needed.

No extension versions or function inventories are guaranteed by the plugin. Do not infer SWS from ReaPack, ReaImGui from ReaPack, or installed packages from the presence of the package manager.
