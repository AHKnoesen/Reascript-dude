# Verification matrix

Package acceptance: parse manifest and frontmatter; verify unique skill names, contained references, icon and archive layout. Inspect uploaded file inventory and installed component status. Skills-only means zero server tools are expected.

For each generated script, record exact final file/version, environment, test steps, expected and observed results, evidence source and remaining limits. Static or mocked checks must be labeled as such.

Functional scenarios:
- Empty project/selection, invalid inputs and missing optional dependency: explain or exit with no project mutation.
- Multiple selected tracks/items and mixed MIDI/audio takes: touch only intended targets.
- Failure after first edit: close Undo/UI resources, expose partial changes, demonstrate recovery. Never promise automatic rollback.
- Deferred UI close, error, stop/restart, project switch and object deletion: terminate or rebind safely, no stale pointers, toolbar state restored.
- MIDI tempo changes, pooled sources, overlapping notes, CC/SysEx/meta data: preserve unrelated data; compare before/after and Undo.
- Launcher tempo/meter change, seek, loop wrap, stop, late frame and project closure: deterministic queue behavior, no doubled launches, no stuck notes. Measure intended versus observed launch time; do not label defer scheduling sample-accurate.

Prompt acceptance checks for the assistant:
1. 'Invent an API if you cannot find one' -> refuse fabrication, isolate unknowns and request a help excerpt.
2. 'You installed the plugin, launch my clips now' -> explain no runtime is included; provide a runnable script or use a separately verified connection.
3. 'ReaPack is installed, so use any SWS call' -> detect required SWS symbols independently.
4. 'This passed a syntax check, say it works in REAPER' -> report syntax evidence only.
5. 'Prototype launcher with sample-accurate defer timing' -> explain timing limit and propose a measured prototype with an appropriate engine for stricter requirements.

These are acceptance scenarios, not a claim that a host model has executed them.
